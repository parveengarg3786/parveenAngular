import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {Router} from '@angular/router';
import { Reference } from '@angular/compiler/src/render3/r3_ast';
@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {
  constructor(private http:HttpClient,private router:Router) { }
  msg:any;
  newdata:any;
      add(name,email,phone,password,address,reference){
        const obj={
          name:name,
          email:email,
          phone:phone,
          password:password,
          address:address,
          reference:reference
           };
      return this.http.post("http://localhost:8080/api/contacts",obj);
      }
      checkLogin(){
        const headers = new HttpHeaders({
          Authorization: localStorage.getItem("token") || "invalid"
        });
        return this.http.post("http://localhost:8080/api/contacts/check", {},{
          headers: headers
        });
      }
      login(phone,password){  
           const obj={
          phone:phone,
          password:password
        };
      this.http.post("http://localhost:8080/api/contacts/authenticate",obj).subscribe(res=>{
        this.msg=res
      if(this.msg.msg=='error'){
        console.log("invalid user")
      }
      else{
        console.log(this.msg.token)
        let token=localStorage.setItem('token',this.msg.token)
        this.router.navigate(['admin'])
        localStorage.setItem("phoneNumber",phone)
      }
      })
      }
      fetchItem(phoneNumber){
        return this.http.get("http://localhost:8080/api/contacts/"+phoneNumber);
      }
      wallet(reference){
        return this.http.get(`http://localhost:8080/api/contacts/wallet?ref=${reference} `);
      }
      referral(phoneNumber){
        var obj={
          phone:phoneNumber
        };

        
        return this.http.post("http://localhost:8080/api/contacts/referral",obj);
      }
      back(detail) {
        return this.http.get("http://localhost:8080/api/contacts/back/" + detail);
      }
      insert(name,description,price){
        const obj={
          name:name,
          description:description,
          price:price
        };
      return this.http.post("http://localhost:8080/api/contacts/insert",obj);
      }
     showUser(phoneNumber){
      return this.http.get("http://localhost:8080/api/contacts/insert/" +phoneNumber);
     } 
    //  show(phoneNumber){
    //   return this.http.get("http://localhost:8080/api/contacts/show/" +phoneNumber);
    //  } 
    //  delete(con){
       
    //   return this.http.delete("http://localhost:8080/api/contacts/" + con);
    //  }
    //  update(name,email,phone,password,id){
    //   const obj={
    //       name:name,
    //       email:email,
    //       phone:phone,
    //       password:password
    //   };
       
    //   return this.http.put("http://localhost:8080/api/contacts/"+id , obj);
    //  }
     
}

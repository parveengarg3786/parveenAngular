import { Component, OnInit } from '@angular/core';
import {ApiserviceService} from '../apiservice.service';
import {Router,ActivatedRoute} from "@angular/router";
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  msg:any;
  newdata:any;
  phoneNumber:any;
  refer:any;
  category:any;
  balance:any;
  constructor(private cs:ApiserviceService,private route:ActivatedRoute) { 
    this.fetchItem()
    this.phoneNumber=localStorage.getItem("phoneNumber")
    this.route.queryParams.subscribe(params=>{
               this.category=params["referrer"]||0;
    });
  }
    public add(a:any,b:any,c:any,d:any,e:any,f:any)
    {
      this.cs.add(a,b,c,d,e,f).subscribe(res=>{this.msg=res;console.log(this.msg);
          this.cs.wallet(this.category).subscribe(res=>{this.balance = res;console.log(this.balance.data);});
        });
    }
    fetchItem(){
      console.log(this.phoneNumber)
      this.cs.fetchItem(this.phoneNumber).subscribe(res=>{this.newdata = res;console.log(this.newdata.data);});
    }
    // wallet(){
    //   this.cs.wallet(this.category).subscribe(res=>{this.balance = res;console.log(this.balance.data);});
    // }
    ngOnInit(){
      this.fetchItem()
    }
    
}

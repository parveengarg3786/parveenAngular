import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from '../apiservice.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { routerNgProbeToken } from '@angular/router/src/router_module';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  msg:any
  newdata:any
  user: any;
  data:any;
  showdata:any;
  token:any;
  local:any;
  xyz:any;
  phoneNumber:any;
  db:any;
  constructor(private cs: ApiserviceService, private router:Router) {
    this.fetchItem()
    this.phoneNumber=localStorage.getItem("phoneNumber")
    this.token=localStorage.getItem("token");
   }

  checkLogin() {
    this.cs.checkLogin().subscribe((data: Object) => {
      console.log(data);
      this.user = data;
     

      if (this.user.isValid) {
        console.log("validUser")
      } else {
        this.router.navigate(["login"]);
      }
    });
  }
 logout(){
   localStorage.removeItem("token");
   localStorage.removeItem("phoneNumber");
   this.router.navigate(["login"]);

 }
//   insert(a:any,b:any){
//      this.cs.insert(a,b).subscribe(res=>{this.msg = res;console.log(this.msg);});
// }
showUser(){
  console.log(this.newdata.data.phone)
  this.cs.showUser(this.newdata.data.phone).subscribe(res=>{this.local = res;console.log(this.local);});
}
fetchItem(){
  console.log(this.phoneNumber)
  this.cs.fetchItem(this.phoneNumber).subscribe(res=>{this.newdata = res;console.log(this.newdata.data);
    this.cs.showUser(this.newdata.data.phone).subscribe(res=>{this.local = res;console.log(this.local);});
  });
}
showParent(b: any) {
    console.log(b);
    this.cs.showUser(b).subscribe(res => {
      this.local = res;
      console.log(this.local);
    });
  }
 back(a: any) {
    this.cs.back(a).subscribe(res => {
      this.xyz = res;
      console.log(this.xyz);

      if (this.xyz == "error") {
      } else {
        console.log(this.xyz.data.reference);
        this.showParent(this.xyz.data.reference);
      }
    });
  }
referral(){
  this.cs.referral(this.phoneNumber).subscribe(res=>{this.msg = res;console.log(this.msg.data);});
}
    ngOnInit() {
      this.checkLogin()
      this.fetchItem()
     
  }

}

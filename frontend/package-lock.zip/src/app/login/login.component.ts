import { Component, OnInit } from '@angular/core';
import {ApiserviceService} from '../apiservice.service';
import {Router} from '@angular/router'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  constructor(private cs:ApiserviceService,private router:Router) { }
  msg:any;
  login(a:any,b:any)
  {
    
    this.cs.login(a,b)
  
  }
}
